package br.com.fabrica;

public class Siena extends Fiat {

}
