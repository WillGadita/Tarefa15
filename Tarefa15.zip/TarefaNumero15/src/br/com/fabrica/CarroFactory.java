package br.com.fabrica;

public abstract class CarroFactory {
	
	public abstract Toyota montarToyota(); 

	public abstract Fiat montarFiat();
}
