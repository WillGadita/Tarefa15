package br.com.fabrica;

public class Etios extends Toyota {
	
	

}
