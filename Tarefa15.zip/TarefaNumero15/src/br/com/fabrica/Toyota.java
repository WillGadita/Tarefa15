package br.com.fabrica;

public class Toyota {
	

}
