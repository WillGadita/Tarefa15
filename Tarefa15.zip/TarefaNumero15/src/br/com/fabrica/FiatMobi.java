package br.com.fabrica;

public class FiatMobi extends Fiat {

}
