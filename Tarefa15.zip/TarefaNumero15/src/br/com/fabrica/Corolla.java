package br.com.fabrica;

public class Corolla extends Toyota {
	
	

}
