package br.com.fabrica;

public class TesteFactory {
	
	
	
	 
	
	private static Carro montarCarro(String cor) {
		CarroFactory cf = null;
		switch(cor){
		case "atual":
			cf = new CarrosAtuaisFactory();
			break;
		
		case "antigo":
			cf = new CarrosAntigosFactory();
			break;
			
		}
		Carro carro = new Carro();
		carro.setToyota(cf.montarToyota());
		carro.setFiat(cf.montarFiat());
		return carro;
	}
	
	public static void main (String[] args) {
		
		Carro c1 = montarCarro("atual");
		Carro c2 = montarCarro("antigo");
		System.out.println("Fabrica de Carros!!!!");
	}

}
