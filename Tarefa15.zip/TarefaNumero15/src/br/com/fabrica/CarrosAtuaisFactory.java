package br.com.fabrica;

public class CarrosAtuaisFactory extends CarroFactory {


	public Toyota montarToyota() {
          return new Corolla();

	}


	public Fiat montarFiat() {
         return new FiatMobi();

	}

	
	
}
