package br.com.fabrica;

public class CarrosAntigosFactory extends CarroFactory  {

	@Override
	public Toyota montarToyota() {
		return new Etios();
	}

	@Override
	public Fiat montarFiat() {
		return new Siena();
		
	}

}
