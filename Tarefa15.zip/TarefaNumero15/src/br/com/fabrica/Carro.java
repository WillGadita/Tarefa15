package br.com.fabrica;

public class Carro {
	
	Toyota toyota; 
    Fiat fiat;
	public Toyota getToyota() {
		return toyota;
	}
	public void setToyota(Toyota toyota) {
		this.toyota = toyota;
	}
	public Fiat getFiat() {
		return fiat;
	}
	public void setFiat(Fiat fiat) {
		this.fiat = fiat;
	}
    
    

}
